Alpha Centauri
An environment map by Mighty Pete

    * Updated 2000-04-20
    * Check out other great artwork by Mighty Pete
    * No email address is on file for Mighty Pete
    * Visit Mighty Pete's homepage
    * Check out other great environment maps with the same theme: Alien worlds

Be sure to check out the matching graphics in the Bloody Ages texture collection!

This environment map is in the public domain, and can be used freely in this format in non-commercial projects. For commercial projects or conversions to another format, please contact the artist.